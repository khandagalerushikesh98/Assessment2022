import java.util.ArrayList;
import java.util.Arrays;

public class PlanetaryMotion {
    int slno;
    String planet;
    String[] gases;
    int moons;
    boolean rings;


    public PlanetaryMotion() {
    }

    public PlanetaryMotion(int slno, String planet, String[] gases, int moons, boolean rings) {
        super();
        this.slno = slno;
        this.planet = planet;
        this.gases = gases;
        this.moons = moons;
        this.rings = rings;
    }
    @Override
    public String toString() {
        return "Planet Details :  " + slno +". "+
                " planet name ='" + planet + '\'' +
                ", gases found=" + Arrays.toString(gases) +
                ", moons=" + moons +
                ", rings=" + (rings ? "Yes" : "No");
    }

    public static String numberOfMoonsWithRing(ArrayList<PlanetaryMotion> a) {
        ArrayList<Integer> count = new ArrayList<>();
        ArrayList<String> countS = new ArrayList<>();
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i).rings) {
                countS.add(a.get(i).planet + ":" + a.get(i).moons);
            }
        }
        if (countS.isEmpty())
            return " We dont have any Planet having Ring !!! ";
        return countS.toString();
    }

    public static String numberOfMoonsWoutRing(ArrayList<PlanetaryMotion> a) {
        ArrayList<String> countS = new ArrayList<>();
        for (int i = 0; i < a.size(); i++) {
            if (!a.get(i).rings) {
                countS.add(a.get(i).planet + ":" + a.get(i).moons);
            }
        }
        if (countS.isEmpty())
            return "Well !!! Every planet got a Ring.";
        return countS.toString();
    }


    public static String gasMy(ArrayList<String> gas){
        ArrayList<String> Finalgas =new ArrayList<>();
        boolean [] visit = new boolean[gas.size()];
        int max = 0;
        for(int i=0;i<gas.size();i++){
            if(visit[i]==true)
                continue;
            int count =1;
            for(int j=i+1;j<gas.size();j++){
                if(gas.get(i).equals(gas.get(j))){
                    visit[j]=true;
                    count++;
                }
            }
            if(max==count) {
                Finalgas.add(gas.get(i));
                max=count;
            }
            if(max<count){
                Finalgas.clear();
                Finalgas.add(gas.get(i));
                max=count;
            }

        }
        if(Finalgas.isEmpty())
            return "No gases in any of our Planets";
        else
            return Finalgas.toString();
    }

//    public static String gases(ArrayList<String> a) {
//        int freq[] = new int[a.size()];
//        for (int i = 0; i < a.size(); i++) {
//            String gas = a.get(i);
////            System.out.println(gas);
//            int count = 0;
//            for (int j = i + 1; j < a.size(); j++) {
//                String g1 = a.get(j);
//                if (gas.equals(g1)) {
//                    count++;
//                    freq[j] = -1;
//                }
//            }
//            if (freq[i] != -1) {
//                freq[i] = count;
//            }
//        }
//        int max = freq[0];
//        ArrayList<String> maxg = new ArrayList<>();
//        for (int i = 0; i < freq.length; i++) {
//            if (max <= freq[i])
//                max = freq[i];
//        }
//        for (int i = 0; i < freq.length; i++) {
//            if (max == freq[i]) {
//                maxg.add(a.get(i));
////                System.out.println(maxg.get(i));
//            }
//        }
//        if(maxg.isEmpty())
//            return "No gases in any of our Planets";
//        else
//        return maxg.toString();
//
//    }
}
